
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { RecommendationRequest, Outfit, ChatMessage } from "../types";

/**
 * Utility for retrying API calls with exponential backoff.
 * Handles 429 (Resource Exhausted) and other transient errors.
 */
async function withRetry<T>(fn: () => Promise<T>, maxRetries = 4, initialDelay = 2000): Promise<T> {
  let lastError: any;
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error: any) {
      lastError = error;
      const errorMessage = error?.message || "";
      const isQuotaError = errorMessage.includes('429') || errorMessage.includes('RESOURCE_EXHAUSTED');
      const isTransient = isQuotaError || errorMessage.includes('500') || errorMessage.includes('503');
      
      if (isTransient && i < maxRetries - 1) {
        // Add jitter to avoid thundering herd problem
        const jitter = Math.random() * 1000;
        const delay = (initialDelay * Math.pow(2, i)) + jitter;
        console.warn(`Gemini API error (retry ${i + 1}/${maxRetries}): ${errorMessage}. Retrying in ${Math.round(delay)}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      throw error;
    }
  }
  throw lastError;
}

/**
 * Basic Styling Recommendation - Using Flash for higher quota and fast response.
 */
export async function getStylingRecommendation(params: RecommendationRequest): Promise<Outfit> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await withRetry(async () => {
    return await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Recommend a professional full outfit for a ${params.gender} in the ${params.ageGroup} age group for a ${params.occasion} occasion. 
      Preference: ${params.fabric} fabric, ${params.style} style, budget around ${params.budget}. 
      
      Instructions:
      1. Ensure the clothing is highly age-appropriate and sophisticated.
      2. Focus on a mix of casual and traditional wear if applicable.
      3. Provide detailed names and descriptions.
      4. Do NOT provide image URLs; the system will generate them separately.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            primary: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                description: { type: Type.STRING },
                price: { type: Type.NUMBER }
              },
              required: ["name", "description", "price"]
            },
            bottom: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                description: { type: Type.STRING },
                price: { type: Type.NUMBER }
              }
            },
            accessories: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  description: { type: Type.STRING },
                  price: { type: Type.NUMBER }
                }
              }
            },
            footwear: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                description: { type: Type.STRING },
                price: { type: Type.NUMBER }
              }
            },
            celebrityInspo: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                description: { type: Type.STRING },
                occasion: { type: Type.STRING }
              }
            }
          },
          required: ["title", "primary", "footwear", "celebrityInspo"]
        }
      }
    });
  });

  const text = response.text;
  if (!text) throw new Error("Our stylist is currently unavailable. Please try again.");
  
  const outfit = JSON.parse(text);
  
  if (!outfit.primary) outfit.primary = { name: 'Signature Garment', description: 'Expertly tailored piece', price: 0 };
  if (!outfit.footwear) outfit.footwear = { name: 'Premium Footwear', description: 'Coordinated elegant shoes', price: 0 };
  if (!outfit.accessories) outfit.accessories = [];

  const injectImage = (item: any, type: string) => {
    if (item && !item.imageUrl) {
      const genderLow = params.gender.toLowerCase();
      const genderTerm = genderLow === 'male' ? 'men' : genderLow === 'female' ? 'women' : 'unisex';
      
      let prompt = "";
      if (type === 'celebrity style') {
         prompt = `high-end editorial fashion photography of ${item.name} wearing ${item.description}, red carpet luxury, high quality, 8k`;
      } else {
         prompt = `professional high-end fashion catalog photography of ${item.name} for ${genderTerm}, ${item.description}, clean background, sharp focus, fashion studio lighting`;
      }

      const shortPrompt = prompt.substring(0, 400);
      item.imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(shortPrompt)}?width=800&height=1000&nologo=true&seed=${Math.floor(Math.random() * 10000)}`;
    }
  };

  injectImage(outfit.primary, 'clothing');
  injectImage(outfit.bottom, 'trousers');
  outfit.accessories?.forEach((acc: any) => injectImage(acc, 'accessory'));
  injectImage(outfit.footwear, 'shoes');
  injectImage(outfit.celebrityInspo, 'celebrity style');

  return outfit;
}

/**
 * Image Editing with Gemini 2.5 Flash Image
 */
export async function editFashionImage(imageBase64: string, prompt: string): Promise<string> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const base64Data = imageBase64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");
  
  const response = await withRetry(async () => {
    return await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: base64Data } },
          { text: prompt }
        ]
      }
    });
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
  }
  throw new Error("Editing failed.");
}

/**
 * Virtual Try-On - Now sequential in the UI to avoid concurrent limit hits.
 */
export async function generateVirtualTryOn(userImageBase64: string, outfitDescription: string, gender: string = 'person'): Promise<string> {
  return editFashionImage(userImageBase64, `Update this image to show the ${gender} wearing: ${outfitDescription}. Ensure the clothing is a perfect fit, maintaining the person's face and pose. Photorealistic fashion photography style.`);
}

/**
 * High-Quality Image Generation (Gemini 3 Pro Image)
 */
export async function generateCustomImage(prompt: string, aspectRatio: string = "1:1", imageSize: string = "1K"): Promise<string> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await withRetry(async () => {
    return await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: [{ text: prompt }],
      config: {
        imageConfig: {
          aspectRatio: aspectRatio as any,
          imageSize: imageSize as any
        }
      }
    });
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
  }
  throw new Error("Generation failed.");
}

/**
 * Veo Video Generation (Animation / Prompt)
 */
export async function generateVeoVideo(prompt: string, imageBase64?: string, isPortrait: boolean = false): Promise<string> {
  const config: any = {
    numberOfVideos: 1,
    resolution: '720p',
    aspectRatio: isPortrait ? '9:16' : '16:9'
  };

  const payload: any = {
    model: 'veo-3.1-fast-generate-preview',
    prompt,
    config
  };

  if (imageBase64) {
    payload.image = {
      imageBytes: imageBase64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, ""),
      mimeType: 'image/jpeg'
    };
  }

  const aiForVideo = new GoogleGenAI({ apiKey: process.env.API_KEY });
  let operation = await withRetry(async () => await aiForVideo.models.generateVideos(payload));

  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await withRetry(async () => await aiForVideo.operations.getVideosOperation({ operation: operation }));
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  const videoResp = await withRetry(async () => await fetch(`${downloadLink}&key=${process.env.API_KEY}`));
  const blob = await videoResp.blob();
  return URL.createObjectURL(blob);
}

/**
 * Analysis of Style (Gemini 3 Flash)
 */
export async function analyzeStyleImage(imageBase64: string): Promise<string> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const base64Data = imageBase64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, "");
  
  const response = await withRetry(async () => {
    return await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: base64Data } },
          { text: "Analyze this person's outfit. Describe the style, key garments, color palette, and fabric types. Provide a professional styling tip to elevate this specific look." }
        ]
      }
    });
  });
  return response.text || "Analysis failed.";
}

/**
 * Advanced Chatbot (Gemini 2.5 Flash Lite)
 */
export async function getStylistChatResponse(
  history: ChatMessage[], 
  prompt: string, 
  userContext?: { ageGroup?: string; gender?: string }
): Promise<{ text: string; isGrounded: boolean; sources?: any[] }> {

  const needsSearch = /trending|current|latest|news|new|collection|events|olympics|awards/i.test(prompt);
  const model = needsSearch ? 'gemini-3-flash-preview' : 'gemini-2.5-flash-lite';
  
  const aiChat = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const chatConfig: any = {
    systemInstruction: `You are StyleSense AI Stylist. User is ${userContext?.gender || 'someone'} in ${userContext?.ageGroup || 'any'} age group. Be helpful, professional, and trendy.`
  };

  if (needsSearch) {
    chatConfig.tools = [{ googleSearch: {} }];
  }

  const chat = aiChat.chats.create({
    model,
    history: history.map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    })),
    config: chatConfig
  });

  const response = await withRetry(async () => await chat.sendMessage({ message: prompt }));
  
  return {
    text: response.text || "I'm here to help you refine your style.",
    isGrounded: !!response.candidates?.[0]?.groundingMetadata,
    sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks
  };
}
