
import React from 'react';
import { AppRoute } from '../types';
import { ShieldCheck, CreditCard, Truck, Apple } from 'lucide-react';

interface Props { navigate: (route: AppRoute) => void; }

const Checkout: React.FC<Props> = ({ navigate }) => {
  return (
    <div className="py-20 px-6 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
        <div className="lg:col-span-2 space-y-12">
          <div>
            <h1 className="text-3xl font-playfair font-bold mb-8">Checkout</h1>
            <div className="space-y-8">
              <section className="space-y-6">
                <h3 className="text-lg font-bold flex items-center gap-2">
                  <Truck className="w-5 h-5 text-stone-400" />
                  Shipping Information
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input className="w-full bg-stone-100 border-none rounded-xl px-4 py-3 text-sm" placeholder="First Name" />
                  <input className="w-full bg-stone-100 border-none rounded-xl px-4 py-3 text-sm" placeholder="Last Name" />
                  <input className="w-full bg-stone-100 border-none rounded-xl px-4 py-3 text-sm md:col-span-2" placeholder="Full Address" />
                  <input className="w-full bg-stone-100 border-none rounded-xl px-4 py-3 text-sm" placeholder="City" />
                  <input className="w-full bg-stone-100 border-none rounded-xl px-4 py-3 text-sm" placeholder="Zip Code" />
                </div>
              </section>

              <section className="space-y-6">
                <h3 className="text-lg font-bold flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-stone-400" />
                  Payment Method
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <button className="p-4 border-2 border-stone-900 rounded-2xl flex flex-col items-center gap-2">
                    <CreditCard className="w-6 h-6" />
                    <span className="text-xs font-bold">Credit Card</span>
                  </button>
                  <button className="p-4 border-2 border-stone-100 rounded-2xl flex flex-col items-center gap-2 opacity-50">
                    <Apple className="w-6 h-6" />
                    <span className="text-xs font-bold">Apple Pay</span>
                  </button>
                  <button className="p-4 border-2 border-stone-100 rounded-2xl flex flex-col items-center gap-2 opacity-50">
                    <span className="text-lg font-bold">PayPal</span>
                  </button>
                </div>
              </section>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-white border border-stone-100 rounded-3xl p-8 shadow-sm">
            <h3 className="text-lg font-bold mb-6">Order Summary</h3>
            <div className="space-y-4 mb-8">
              <div className="flex justify-between items-center text-sm">
                <div className="flex gap-4 items-center">
                  <div className="w-12 h-12 bg-stone-100 rounded-lg"></div>
                  <div>
                    <p className="font-semibold">Bespoke Silk Sherwani</p>
                    <p className="text-stone-400 text-xs">Custom Tailored</p>
                  </div>
                </div>
                <span className="font-bold">$245.00</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <div className="flex gap-4 items-center">
                  <div className="w-12 h-12 bg-stone-100 rounded-lg"></div>
                  <div>
                    <p className="font-semibold">Tan Leather Mojaris</p>
                    <p className="text-stone-400 text-xs">Footwear</p>
                  </div>
                </div>
                <span className="font-bold">$85.00</span>
              </div>
            </div>

            <div className="space-y-3 pt-6 border-t border-stone-100 text-sm">
              <div className="flex justify-between">
                <span className="text-stone-500">Subtotal</span>
                <span>$330.00</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Shipping</span>
                <span className="text-emerald-600 font-bold">Free</span>
              </div>
              <div className="flex justify-between text-lg font-bold pt-4">
                <span>Total</span>
                <span>$330.00</span>
              </div>
            </div>

            <button 
              onClick={() => alert("This is a prototype demo. No payment was processed.")}
              className="w-full bg-stone-900 text-white py-5 rounded-2xl font-bold mt-8 shadow-xl hover:bg-stone-800 transition-all"
            >
              Complete Purchase
            </button>
            
            <div className="mt-6 flex items-center justify-center gap-2 text-[10px] text-stone-400 uppercase font-bold tracking-widest">
              <ShieldCheck className="w-4 h-4 text-stone-300" />
              Secure Checkout Powered by Gemini
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
