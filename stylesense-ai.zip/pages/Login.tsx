
import React, { useState, useEffect, useRef } from 'react';
import * as THREE from 'three';

interface Props {
  onLogin: () => void;
}

const Login: React.FC<Props> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    // --- THREE.JS SETUP ---
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    
    const renderer = new THREE.WebGLRenderer({ 
      canvas: canvasRef.current, 
      antialias: false, // Disabled for mobile performance
      alpha: true,
      powerPreference: "high-performance", // Hint for GPU
      precision: "mediump" // Sufficient for background visuals
    });
    
    renderer.setSize(window.innerWidth, window.innerHeight);
    // Capped pixel ratio to 1.2 for maximum responsiveness on high-DPI mobile screens
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.2));

    // --- OPTIMIZED OBJECTS ---
    // 1. Silk Fabric Ribbon - Reduced segments to 12x12 (144 vertices)
    const ribbonGeometry = new THREE.PlaneGeometry(14, 28, 12, 12);
    // Switched to MeshStandardMaterial from MeshPhysicalMaterial for faster shading
    const ribbonMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      side: THREE.DoubleSide,
      roughness: 0.4,
      metalness: 0.1,
      transparent: true,
      opacity: 0.4
    });
    const ribbon = new THREE.Mesh(ribbonGeometry, ribbonMaterial);
    ribbon.rotation.x = -Math.PI / 2.5;
    ribbon.position.z = -8;
    scene.add(ribbon);

    // 2. Jewelry Accessories - Minimal geometry
    const jewelryGroup = new THREE.Group();
    const goldMat = new THREE.MeshStandardMaterial({ 
      color: 0xc5a028, 
      metalness: 0.8, 
      roughness: 0.3 
    });

    // Reduced count to 4 for mobile performance
    for (let i = 0; i < 4; i++) {
      const isRing = Math.random() > 0.5;
      // Low-poly counts for torus and icosahedron
      const geo = isRing 
        ? new THREE.TorusGeometry(0.3, 0.04, 6, 24) 
        : new THREE.IcosahedronGeometry(0.2, 0);
      
      const mesh = new THREE.Mesh(geo, goldMat);
      mesh.position.set(
        (Math.random() - 0.5) * 10,
        (Math.random() - 0.5) * 10,
        (Math.random() - 0.5) * 4 - 4
      );
      mesh.userData.speed = Math.random() * 0.4 + 0.1;
      jewelryGroup.add(mesh);
    }
    scene.add(jewelryGroup);

    // --- LIGHTING ---
    // Simple lighting is faster than multiple complex point lights
    scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    const mainLight = new THREE.DirectionalLight(0xffffff, 1.5);
    mainLight.position.set(2, 5, 5);
    scene.add(mainLight);

    camera.position.z = 5;

    // --- ANIMATION ---
    let mouseX = 0;
    let mouseY = 0;
    const clock = new THREE.Clock();

    const onMouseMove = (event: MouseEvent) => {
      mouseX = (event.clientX / window.innerWidth) - 0.5;
      mouseY = (event.clientY / window.innerHeight) - 0.5;
    };
    window.addEventListener('mousemove', onMouseMove);

    const animate = () => {
      const delta = clock.getElapsedTime();
      
      // Animate Ribbon Vertices (Efficient for low-poly counts)
      const positions = ribbon.geometry.attributes.position;
      for (let i = 0; i < positions.count; i++) {
        const x = positions.getX(i);
        const y = positions.getY(i);
        const z = Math.sin(x * 0.3 + delta) * 0.6 + Math.cos(y * 0.2 + delta) * 0.4;
        positions.setZ(i, z);
      }
      positions.needsUpdate = true;

      // Animate Jewelry
      jewelryGroup.children.forEach((child) => {
        child.rotation.x += 0.008 * child.userData.speed;
        child.rotation.y += 0.012 * child.userData.speed;
        child.position.y += Math.sin(delta + child.position.x) * 0.0008;
      });

      // Camera Parallax - Limited range for smoothness
      scene.rotation.y += (mouseX * 0.03 - scene.rotation.y) * 0.04;
      scene.rotation.x += (mouseY * 0.03 - scene.rotation.x) * 0.04;

      renderer.render(scene, camera);
      requestRef.current = requestAnimationFrame(animate);
    };

    animate();

    // --- RESIZE ---
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', onMouseMove);
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
      renderer.dispose();
      ribbonGeometry.dispose();
      ribbonMaterial.dispose();
      goldMat.dispose();
    };
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes('@')) {
      setEmailError('Please enter a valid email.');
      return;
    }
    onLogin();
  };

  return (
    <div className="min-h-screen relative flex items-center justify-center bg-stone-950 overflow-hidden px-4">
      {/* 3D Background */}
      <canvas ref={canvasRef} className="absolute inset-0 z-0 pointer-events-none" aria-hidden="true" />
      <div className="absolute inset-0 bg-stone-950/60 pointer-events-none" />
      
      <div className="relative z-10 w-full max-w-md p-8 sm:p-10 bg-white/5 backdrop-blur-2xl rounded-[32px] sm:rounded-[40px] shadow-2xl border border-white/10">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-amber-400 mb-6 shadow-[0_0_40px_rgba(251,191,36,0.2)]">
            <span className="text-stone-900 font-playfair font-bold text-2xl">S</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-playfair font-bold text-white mb-2 tracking-tight">StyleSense AI</h1>
          <p className="text-stone-400 text-xs sm:text-sm tracking-widest uppercase font-medium">Digital Style Atelier</p>
        </div>

        <form className="space-y-4" onSubmit={handleSubmit}>
          {!isLogin && (
            <div>
              <label className="block text-[10px] font-bold text-stone-500 uppercase tracking-widest mb-1.5 ml-1">Full Name</label>
              <input type="text" className="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none text-white text-sm transition-all" placeholder="John Doe" required />
            </div>
          )}
          <div>
            <label className="block text-[10px] font-bold text-stone-500 uppercase tracking-widest mb-1.5 ml-1">Email</label>
            <input 
              type="email" 
              value={email} 
              onChange={(e) => { setEmail(e.target.value); setEmailError(''); }} 
              className={`w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl focus:ring-2 outline-none text-white text-sm transition-all ${emailError ? 'ring-red-500 ring-2' : 'focus:ring-amber-500'}`} 
              placeholder="curator@stylesense.ai" 
              required 
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-stone-500 uppercase tracking-widest mb-1.5 ml-1">Access Pin</label>
            <input type="password" className="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none text-white text-sm transition-all" placeholder="••••••••" required />
          </div>

          <button 
            type="submit" 
            className="w-full py-4.5 bg-amber-400 text-stone-900 rounded-xl font-bold text-sm hover:bg-amber-300 hover:scale-[1.01] active:scale-[0.99] transition-all shadow-xl mt-6"
          >
            {isLogin ? 'Enter Atelier' : 'Create Profile'}
          </button>
        </form>

        <div className="mt-8 text-center text-xs sm:text-sm">
          <span className="text-stone-500">{isLogin ? "No account?" : "Returning guest?"}</span>
          <button 
            onClick={() => setIsLogin(!isLogin)} 
            className="ml-2 font-bold text-white hover:text-amber-400 transition-colors py-1 focus:outline-none"
          >
            {isLogin ? 'Join StyleSense' : 'Sign In'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Login;
