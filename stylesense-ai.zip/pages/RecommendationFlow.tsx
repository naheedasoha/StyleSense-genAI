
import React, { useState, useEffect } from 'react';
import { AppRoute, RecommendationRequest, Outfit } from '../types';
import { getStylingRecommendation } from '../services/geminiService';
import { 
  Sparkles, 
  Loader2, 
  ChevronRight, 
  RotateCcw, 
  PartyPopper, 
  Baby, 
  GraduationCap, 
  User, 
  Coffee, 
  Bookmark, 
  BookmarkCheck,
  Backpack,
  Briefcase,
  Glasses,
  AlertCircle,
  Timer
} from 'lucide-react';

interface Props {
  navigate: (route: AppRoute) => void;
  onUpdateContext: (context: {ageGroup?: string, gender?: string}) => void;
  onSelectOutfit: (outfit: Outfit) => void;
}

const RecommendationFlow: React.FC<Props> = ({ navigate, onUpdateContext, onSelectOutfit }) => {
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isQuotaError, setIsQuotaError] = useState(false);
  const [result, setResult] = useState<Outfit | null>(null);
  const [isSaved, setIsSaved] = useState(false);
  const [formData, setFormData] = useState<RecommendationRequest>({
    gender: '',
    ageGroup: '',
    occasion: '',
    fabric: '',
    style: '',
    budget: ''
  });

  const ageGroups = [
    { value: 'Infant (0-1)', label: 'Infant', sub: '0-1 Years', icon: <Baby className="w-6 h-6" /> },
    { value: 'Toddler (1-4)', label: 'Toddler', sub: '1-4 Years', icon: <Baby className="w-6 h-6" /> },
    { value: 'Child (5-12)', label: 'Child', sub: '5-12 Years', icon: <Backpack className="w-6 h-6" /> },
    { value: 'Teen (13-19)', label: 'Teen', sub: '13-19 Years', icon: <GraduationCap className="w-6 h-6" /> },
    { value: 'Adult (20-60)', label: 'Adult', sub: '20-60 Years', icon: <Briefcase className="w-6 h-6" /> },
    { value: 'Senior (60+)', label: 'Senior', sub: '60+ Years', icon: <Glasses className="w-6 h-6" /> }
  ];

  const steps = [
    { key: 'gender', label: 'Who are we styling?', options: [
      { value: 'Male', img: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=150&h=150&fit=crop' },
      { value: 'Female', img: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=150&h=150&fit=crop' },
      { value: 'Non-binary', img: 'https://images.unsplash.com/photo-1543132220-4bf3de6e10ae?q=80&w=150&h=150&fit=crop' }
    ]},
    { key: 'ageGroup', label: 'Select age group', options: ageGroups.map(a => ({ value: a.value, label: a.label, sub: a.sub, icon: a.icon })) },
    { key: 'occasion', label: 'What is the occasion?', options: [
      { value: 'Casual Outing', img: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=150&h=150&fit=crop' },
      { value: 'Wedding / Festive', img: 'https://images.unsplash.com/photo-1546032996-6dfacbacbf3f?q=80&w=150&h=150&fit=crop' },
      { value: 'Office Wear', img: 'https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?q=80&w=150&h=150&fit=crop' },
      { value: 'Evening Party', img: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=150&h=150&fit=crop' }
    ]},
    { key: 'fabric', label: 'Preferred fabric?', options: [
      { value: 'Cotton', img: 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?q=80&w=150&h=150&fit=crop' },
      { value: 'Silk', img: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=150&h=150&fit=crop' },
      { value: 'Linen', img: 'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=150&h=150&fit=crop' },
      { value: 'Denim', img: 'https://images.unsplash.com/photo-1542272604-787c3835535d?q=80&w=150&h=150&fit=crop' },
      { value: 'No Preference', img: 'https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?q=80&w=150&h=150&fit=crop' }
    ]},
    { key: 'style', label: 'Your personal style?', options: [
      { value: 'Classic', img: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=150&h=150&fit=crop' },
      { value: 'Minimalist', img: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?q=80&w=150&h=150&fit=crop' },
      { value: 'Bohemian', img: 'https://images.unsplash.com/photo-1502716119720-b23a93e5fe1b?q=80&w=150&h=150&fit=crop' },
      { value: 'High-Fashion / Trendy', img: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?q=80&w=150&h=150&fit=crop' }
    ]},
    { key: 'budget', label: 'Estimated budget range?', options: [
      { value: '$50 - $150', img: 'https://images.unsplash.com/photo-1556742049-04ff4361ccb8?q=80&w=150&h=150&fit=crop' },
      { value: '$150 - $500', img: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=150&h=150&fit=crop' },
      { value: '$500 - $1500', img: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=150&h=150&fit=crop' },
      { value: 'Luxury', img: 'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=150&h=150&fit=crop' }
    ]},
  ];

  const handleOptionSelect = (option: string) => {
    const key = steps[step].key as keyof RecommendationRequest;
    const updatedData = { ...formData, [key]: option };
    setFormData(updatedData);

    if (key === 'ageGroup' || key === 'gender') {
      onUpdateContext({
        ageGroup: key === 'ageGroup' ? option : formData.ageGroup,
        gender: key === 'gender' ? option : formData.gender
      });
    }

    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      handleFinalize(updatedData);
    }
  };

  const handleFinalize = async (finalData: RecommendationRequest) => {
    setLoading(true);
    setError(null);
    setIsQuotaError(false);
    setIsSaved(false);
    try {
      const recommendation = await getStylingRecommendation(finalData);
      setResult(recommendation);
    } catch (err: any) {
      console.error(err);
      if (err.message?.includes('429') || err.message?.includes('RESOURCE_EXHAUSTED')) {
        setIsQuotaError(true);
        setError("Our AI Stylist is popular today! We've temporarily reached our request limit. Please try again in 30 seconds.");
      } else {
        setError("Our stylist hit a snag while curating your look. Please check your connection and try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setStep(0);
    setResult(null);
    setError(null);
    setIsQuotaError(false);
    setFormData({
      gender: '',
      ageGroup: '',
      occasion: '',
      fabric: '',
      style: '',
      budget: ''
    });
  };

  const saveOutfit = () => {
    if (!result) return;
    const saved = localStorage.getItem('styleSense_savedOutfits');
    const savedOutfits: (Outfit & { date: string })[] = saved ? JSON.parse(saved) : [];
    if (!savedOutfits.find(o => o.title === result.title)) {
      savedOutfits.push({ ...result, date: new Date().toISOString() });
      localStorage.setItem('styleSense_savedOutfits', JSON.stringify(savedOutfits));
    }
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center" role="status">
        <div className="relative w-24 h-24 mb-10">
          <div className="absolute inset-0 rounded-full border-4 border-stone-100"></div>
          <div className="absolute inset-0 rounded-full border-4 border-amber-500 border-t-transparent animate-spin"></div>
          <Sparkles className="w-8 h-8 text-amber-500 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse" />
        </div>
        <h2 className="text-3xl font-playfair font-bold text-stone-900 mb-2">Curating Excellence</h2>
        <p className="text-stone-500 max-w-sm">Crafting a bespoke ensemble for a {formData.ageGroup} {formData.gender}.</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center animate-in fade-in zoom-in duration-300">
        <div className={`w-24 h-24 rounded-full flex items-center justify-center mb-8 ${isQuotaError ? 'bg-amber-50' : 'bg-red-50 shadow-xl shadow-red-100'}`}>
          {isQuotaError ? <Timer className="w-12 h-12 text-amber-500 animate-pulse" /> : <AlertCircle className="w-12 h-12 text-red-500" />}
        </div>
        <h2 className="text-3xl font-playfair font-bold text-stone-900 mb-3">
          {isQuotaError ? 'AI Stylist Resting' : 'Connection Interrupted'}
        </h2>
        <p className="text-stone-500 max-w-md mb-10 leading-relaxed">{error}</p>
        <div className="flex flex-col sm:flex-row gap-4">
          <button onClick={() => handleFinalize(formData)} className="bg-stone-900 text-white px-10 py-4 rounded-full font-bold shadow-2xl hover:bg-stone-800 transition-all active:scale-95">
            Retry Recommendation
          </button>
          <button onClick={handleReset} className="border border-stone-200 px-10 py-4 rounded-full font-bold hover:bg-stone-50 transition-all">
            Start Over
          </button>
        </div>
      </div>
    );
  }

  if (result) {
    const totalPriceValue = (
      (result.primary?.price || 0) + 
      (result.bottom?.price || 0) + 
      (result.accessories?.reduce((acc, curr) => acc + (curr?.price || 0), 0) || 0) + 
      (result.footwear?.price || 0)
    ).toFixed(2);

    return (
      <div className="py-20 px-6 max-w-7xl mx-auto animate-in fade-in duration-1000">
        <div className="flex flex-col md:flex-row justify-between items-start mb-16 gap-10">
          <header className="max-w-3xl">
            <div className="flex items-center gap-2 text-amber-600 text-[10px] font-black tracking-[0.3em] uppercase mb-4">
              <Sparkles className="w-4 h-4" /> AI Tailored Ensemble
            </div>
            <h1 className="text-5xl md:text-7xl font-playfair font-bold text-stone-900 mb-6 leading-tight">{result.title}</h1>
            <p className="text-stone-500 text-lg leading-relaxed font-light">
              Curated specifically for a {formData.ageGroup} {formData.gender}, highlighting {formData.fabric} for the {formData.occasion}.
            </p>
          </header>
          <div className="flex flex-wrap gap-4">
            <button 
              onClick={saveOutfit}
              className={`flex items-center gap-2 text-sm font-bold transition-all px-8 py-4 rounded-full border shadow-sm ${isSaved ? 'bg-amber-50 border-amber-200 text-amber-700' : 'bg-white border-stone-100 text-stone-600 hover:text-stone-900 hover:shadow-md'}`}
            >
              {isSaved ? <BookmarkCheck className="w-5 h-5" /> : <Bookmark className="w-5 h-5" />}
              {isSaved ? 'Look Archived' : 'Save Outfit'}
            </button>
            <button onClick={handleReset} className="flex items-center gap-2 text-sm font-bold text-stone-400 hover:text-stone-900 transition-colors px-4">
              <RotateCcw className="w-4 h-4" /> New Session
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          <div className="lg:col-span-2 space-y-12">
            <section>
              <div className="aspect-[4/5] bg-stone-100 rounded-[56px] overflow-hidden relative group border border-stone-200 shadow-2xl">
                {result.primary?.imageUrl ? (
                  <img src={result.primary.imageUrl} alt={result.primary.name} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-stone-200 text-stone-400">Preview Generation...</div>
                )}
                <div className="absolute top-10 left-10">
                  <span className="bg-black/60 backdrop-blur-xl border border-white/10 px-6 py-3 rounded-full text-[10px] font-black uppercase tracking-[0.2em] text-white">Studio Showcase</span>
                </div>
              </div>
            </section>
            {result.celebrityInspo && (
              <section className="bg-amber-50 rounded-[48px] p-12 flex flex-col md:flex-row gap-12 items-center border border-amber-100 shadow-xl transition-all hover:shadow-2xl">
                <div className="relative flex-shrink-0">
                  <img src={result.celebrityInspo.imageUrl} className="w-48 h-48 rounded-[40px] object-cover shadow-2xl border-4 border-white" alt={result.celebrityInspo.name} />
                  <div className="absolute -bottom-4 -right-4 w-12 h-12 bg-amber-400 rounded-2xl flex items-center justify-center shadow-lg">
                    <Sparkles className="w-6 h-6 text-stone-900" />
                  </div>
                </div>
                <div className="flex-1 text-center md:text-left">
                  <div className="text-amber-600 text-[10px] font-black uppercase tracking-[0.3em] mb-3">Red Carpet Muse</div>
                  <h4 className="text-3xl font-playfair font-bold text-amber-900 mb-4">{result.celebrityInspo.name}</h4>
                  <p className="text-amber-800/70 text-base leading-relaxed mb-8">{result.celebrityInspo.description}</p>
                  <div className="inline-flex items-center gap-3 bg-white px-6 py-3 rounded-full text-xs font-bold text-amber-800 shadow-sm border border-amber-100">
                     <PartyPopper className="w-4 h-4 text-amber-500" /> Event Context: {result.celebrityInspo.occasion}
                  </div>
                </div>
              </section>
            )}
          </div>

          <aside className="space-y-10">
            <div className="bg-white rounded-[56px] border border-stone-100 p-10 shadow-2xl sticky top-24">
              <h3 className="text-[10px] font-black text-stone-400 uppercase tracking-[0.3em] mb-10">The Curated Bundle</h3>
              <ul className="space-y-10">
                <ItemCard item={result.primary} />
                {result.bottom && <ItemCard item={result.bottom} />}
                {result.accessories?.map((acc, i) => <ItemCard key={i} item={acc} />)}
                <ItemCard item={result.footwear} />
              </ul>
              <div className="pt-10 mt-10 border-t border-stone-100">
                <div className="flex justify-between items-end mb-10">
                  <span className="text-stone-400 text-sm font-bold uppercase tracking-widest">Est. Valuation</span>
                  <span className="text-5xl font-playfair font-bold text-stone-900">${totalPriceValue}</span>
                </div>
                <button 
                  onClick={() => navigate(AppRoute.CHECKOUT)}
                  className="w-full bg-stone-900 text-white py-6 rounded-3xl font-bold flex items-center justify-center gap-3 hover:bg-amber-500 hover:text-stone-900 transition-all shadow-2xl active:scale-95"
                >
                  Purchase Complete Look
                  <ChevronRight className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => {
                    onSelectOutfit(result);
                    navigate(AppRoute.TRY_ON);
                  }}
                  className="w-full mt-4 bg-white text-stone-900 border border-stone-100 py-5 rounded-3xl font-bold hover:bg-stone-50 transition-all flex items-center justify-center gap-3 active:scale-95"
                >
                  <Sparkles className="w-4 h-4 text-amber-500" /> Virtual Try-On
                </button>
              </div>
            </div>
          </aside>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[90vh] flex items-center justify-center p-6 bg-stone-50">
      <div className="max-w-4xl w-full bg-white rounded-[64px] shadow-[0_50px_100px_rgba(0,0,0,0.05)] p-12 md:p-24 border border-stone-100 relative overflow-hidden transition-all hover:shadow-amber-200/20">
        <div className="absolute top-0 left-0 w-full h-3 bg-stone-50">
          <div className="h-full bg-amber-400 transition-all duration-1000 ease-out shadow-[0_0_15px_rgba(251,191,36,0.5)]" style={{ width: `${((step + 1) / steps.length) * 100}%` }}></div>
        </div>
        
        <div className="mb-16">
          <span className="text-amber-600 text-[10px] uppercase font-black tracking-[0.4em] mb-6 block">Curating Step {step + 1} of {steps.length}</span>
          <h2 className="text-5xl md:text-6xl font-playfair font-bold text-stone-900 leading-tight">{steps[step].label}</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {steps[step].options.map((option: any, i) => {
            const isAgeStep = steps[step].key === 'ageGroup';
            const hasImage = !!option.img;

            return (
              <button
                key={i}
                onClick={() => handleOptionSelect(option.value)}
                className={`group rounded-[40px] border-2 transition-all relative overflow-hidden text-left hover:border-amber-600 hover:bg-amber-50/10 shadow-sm active:scale-95 ${
                  isAgeStep 
                    ? 'border-stone-100 bg-stone-50 p-8 min-h-[220px] flex flex-col items-start justify-end'
                    : hasImage 
                      ? 'border-stone-100 bg-white aspect-square flex flex-col' 
                      : 'border-stone-100 bg-white items-center flex justify-between p-8'
                }`}
              >
                {hasImage && !isAgeStep ? (
                  <>
                    <img src={option.img} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt={option.value} />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent p-8 flex items-end">
                      <span className="font-bold text-white text-xl tracking-tight">{option.value}</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="relative z-10 w-full">
                       {isAgeStep && (
                         <div className="w-14 h-14 rounded-2xl bg-white border border-stone-100 flex items-center justify-center group-hover:bg-amber-100 group-hover:border-amber-200 transition-all mb-8 shadow-sm">
                            <div className="text-stone-400 group-hover:text-amber-600 transition-transform group-hover:scale-110">
                              {option.icon}
                            </div>
                         </div>
                       )}
                       <div className="flex flex-col">
                          <span className={`font-bold block ${isAgeStep ? 'text-2xl text-stone-900' : 'text-stone-800 text-lg'} group-hover:text-amber-900`}>
                            {isAgeStep ? option.label : option.value}
                          </span>
                          {isAgeStep && (
                            <span className="text-[10px] text-stone-400 font-black uppercase tracking-[0.2em] mt-2">
                              {option.sub}
                            </span>
                          )}
                       </div>
                    </div>
                    {!isAgeStep && !hasImage && (
                      <ChevronRight className="w-6 h-6 text-stone-200 group-hover:text-amber-600 transition-all" />
                    )}
                  </>
                )}
                <div className="absolute -bottom-6 -right-6 opacity-0 group-hover:opacity-10 transition-opacity">
                  <Sparkles className="w-32 h-32 text-amber-600" />
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

const ItemCard = ({ item }: { item: any }) => {
  if (!item) return null;
  return (
    <li className="flex gap-8 group list-none">
      <div className="w-28 h-32 bg-stone-100 rounded-[32px] overflow-hidden flex-shrink-0 border border-stone-200 shadow-sm transition-all group-hover:shadow-xl">
        <img src={item.imageUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt="" />
      </div>
      <div className="flex-1 border-b border-stone-100 pb-6">
        <div className="flex justify-between items-start mb-3">
          <h5 className="font-bold text-stone-900 text-base leading-snug group-hover:text-amber-700 transition-colors">{item.name}</h5>
          <span className="text-base font-black text-stone-900 ml-6 tracking-tight">${item.price}</span>
        </div>
        <p className="text-xs text-stone-400 leading-relaxed line-clamp-2 font-medium">{item.description}</p>
      </div>
    </li>
  );
};

export default RecommendationFlow;
