
import React, { useState } from 'react';
import { AppRoute } from '../types';
import { generateCustomImage, editFashionImage } from '../services/geminiService';
import { Scissors, Ruler, Paintbrush, ChevronRight, Check, Sparkles, Loader2, Image as ImageIcon, Wand2, Shirt } from 'lucide-react';

interface Props { navigate: (route: AppRoute) => void; }

const CustomDesign: React.FC<Props> = ({ navigate }) => {
  const [activeTab, setActiveTab] = useState<'fabric' | 'measurements' | 'finalize' | 'studio'>('fabric');
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiImage, setAiImage] = useState<string | null>(null);
  const [imagePrompt, setImagePrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [imageSize, setImageSize] = useState('1K');
  const [editPrompt, setEditPrompt] = useState('');

  const [design, setDesign] = useState({
    fabric: 'Silk',
    color: '#D4AF37',
    neckline: 'V-Neck',
    sleeve: 'Full',
    chest: 38,
    waist: 32,
    length: 44
  });

  const fabrics = [
    { name: 'Pure Silk', price: '$200', img: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=1888&auto=format&fit=crop', pattern: 'https://www.transparenttextures.com/patterns/silk.png' },
    { name: 'Fine Linen', price: '$120', img: 'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?q=80&w=2070&auto=format&fit=crop', pattern: 'https://www.transparenttextures.com/patterns/linen.png' },
    { name: 'Khadi Cotton', price: '$80', img: 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?q=80&w=1972&auto=format&fit=crop', pattern: 'https://www.transparenttextures.com/patterns/fabric-of-squares.png' }
  ];

  const necklines = [
    { name: 'V-Neck', img: 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?q=80&w=100&h=100&fit=crop' },
    { name: 'Crew Neck', img: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=100&h=100&fit=crop' },
    { name: 'Square', img: 'https://images.unsplash.com/photo-1581044777550-4cfa60707c03?q=80&w=100&h=100&fit=crop' },
    { name: 'Scoop', img: 'https://images.unsplash.com/photo-1554568218-0f1715e72254?q=80&w=100&h=100&fit=crop' }
  ];

  const sleeves = [
    { name: 'Full', img: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=100&h=100&fit=crop' },
    { name: 'Half', img: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=100&h=100&fit=crop' },
    { name: 'Sleeveless', img: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?q=80&w=100&h=100&fit=crop' }
  ];

  const handleGenerate = async () => {
    if (!imagePrompt) return;
    setIsGenerating(true);
    try {
      const url = await generateCustomImage(imagePrompt, aspectRatio, imageSize);
      setAiImage(url);
    } catch (e) {
      alert("Failed to generate image.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleEdit = async () => {
    if (!aiImage || !editPrompt) return;
    setIsGenerating(true);
    try {
      const url = await editFashionImage(aiImage, editPrompt);
      setAiImage(url);
      setEditPrompt('');
    } catch (e) {
      alert("Failed to edit image.");
    } finally {
      setIsGenerating(false);
    }
  };

  const currentFabric = fabrics.find(f => f.name === design.fabric) || fabrics[0];

  return (
    <div className="py-20 px-6 max-w-7xl mx-auto" role="main">
      <header className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
        <div>
          <div className="flex items-center gap-2 text-amber-600 text-xs font-bold tracking-widest uppercase mb-2">
            <Shirt className="w-4 h-4" /> Bespoke Creation
          </div>
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-stone-900 mb-4">The Atelier</h1>
          <p className="text-stone-500 max-w-xl">Every stitch tells a story. Design your unique silhouette with real-time AI visualization.</p>
        </div>
        <nav className="flex bg-stone-100 p-1 rounded-full text-sm font-semibold overflow-x-auto no-scrollbar shadow-inner">
          {['fabric', 'measurements', 'finalize', 'studio'].map((tab) => (
            <button 
              key={tab}
              onClick={() => setActiveTab(tab as any)} 
              className={`px-6 py-2.5 rounded-full capitalize transition-all whitespace-nowrap ${activeTab === tab ? 'bg-white shadow-md text-stone-900 scale-105' : 'text-stone-500 hover:text-stone-700'}`}
            >{tab}</button>
          ))}
        </nav>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        {/* Left: Enhanced Preview Section */}
        <section className="bg-stone-100 rounded-[48px] p-8 flex flex-col items-center justify-center relative overflow-hidden h-[700px] border border-stone-200">
           {activeTab === 'studio' && aiImage ? (
              <div className="w-full h-full relative group">
                <img src={aiImage} className="w-full h-full object-contain rounded-3xl shadow-2xl transition-transform duration-500 group-hover:scale-[1.02]" alt="AI Generated" />
                <div className="absolute inset-x-0 bottom-6 px-6 flex flex-col gap-3 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      value={editPrompt}
                      onChange={(e) => setEditPrompt(e.target.value)}
                      placeholder="Add a retro filter, change color..."
                      className="flex-1 bg-white/95 backdrop-blur border-none rounded-2xl px-5 py-3.5 text-sm shadow-2xl focus:ring-2 focus:ring-amber-500 outline-none"
                    />
                    <button onClick={handleEdit} className="bg-stone-900 text-white p-3.5 rounded-2xl shadow-2xl hover:bg-stone-800 active:scale-95 transition-all">
                      <Wand2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
           ) : (
             <div className="text-center w-full flex flex-col items-center">
                <div className="relative w-80 h-[500px] bg-white rounded-3xl shadow-2xl flex items-center justify-center overflow-hidden border border-stone-100 group">
                  {/* Dynamic Garment SVG Preview */}
                  <svg viewBox="0 0 200 300" className="w-full h-full drop-shadow-2xl">
                    <defs>
                      <pattern id="fabricPattern" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
                        <image href={currentFabric.pattern} x="0" y="0" width="40" height="40" opacity="0.3" />
                      </pattern>
                      <filter id="shadow">
                        <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.2"/>
                      </filter>
                    </defs>

                    {/* Main Body with Texture and Color */}
                    <g filter="url(#shadow)">
                      {/* Torso */}
                      <path 
                        d="M60 40 L140 40 L150 100 L140 280 L60 280 L50 100 Z" 
                        fill={design.color}
                        className="transition-all duration-500"
                      />
                      <path 
                        d="M60 40 L140 40 L150 100 L140 280 L60 280 L50 100 Z" 
                        fill="url(#fabricPattern)"
                        className="transition-all duration-500"
                        style={{ mixBlendMode: 'multiply' }}
                      />

                      {/* Neckline Logic */}
                      <path 
                        d={
                          design.neckline === 'V-Neck' ? "M60 40 Q100 80 140 40 Z" :
                          design.neckline === 'Crew Neck' ? "M60 40 Q100 55 140 40 Z" :
                          design.neckline === 'Square' ? "M60 40 L60 65 L140 65 L140 40 Z" :
                          "M60 40 Q100 100 140 40 Z" // Scoop
                        }
                        fill="#F5F5F4" // Background color to "cut out" the neck
                        className="transition-all duration-500"
                      />

                      {/* Sleeve Logic */}
                      {design.sleeve !== 'Sleeveless' && (
                        <>
                          {/* Left Sleeve */}
                          <path 
                            d={design.sleeve === 'Full' ? "M60 40 L20 180 L45 190 L55 80 Z" : "M60 40 L35 110 L60 120 L55 80 Z"}
                            fill={design.color}
                            className="transition-all duration-500"
                          />
                          <path 
                            d={design.sleeve === 'Full' ? "M60 40 L20 180 L45 190 L55 80 Z" : "M60 40 L35 110 L60 120 L55 80 Z"}
                            fill="url(#fabricPattern)"
                            className="transition-all duration-500"
                            style={{ mixBlendMode: 'multiply' }}
                          />
                          {/* Right Sleeve */}
                          <path 
                            d={design.sleeve === 'Full' ? "M140 40 L180 180 L155 190 L145 80 Z" : "M140 40 L165 110 L140 120 L145 80 Z"}
                            fill={design.color}
                            className="transition-all duration-500"
                          />
                          <path 
                            d={design.sleeve === 'Full' ? "M140 40 L180 180 L155 190 L145 80 Z" : "M140 40 L165 110 L140 120 L145 80 Z"}
                            fill="url(#fabricPattern)"
                            className="transition-all duration-500"
                            style={{ mixBlendMode: 'multiply' }}
                          />
                        </>
                      )}
                    </g>
                  </svg>

                  {/* Highlight Overlay */}
                  <div className="absolute inset-0 pointer-events-none bg-gradient-to-tr from-white/10 to-transparent"></div>
                </div>

                {/* Color Palette Controls */}
                <div className="mt-10 flex flex-wrap gap-4 justify-center bg-white/50 backdrop-blur p-4 rounded-3xl border border-white/50 shadow-sm">
                  {['#D4AF37', '#2D3436', '#E17055', '#00B894', '#6C5CE7', '#E84393', '#F9CA24', '#7ED6DF'].map(c => (
                    <button 
                      key={c} 
                      onClick={() => setDesign({...design, color: c})} 
                      style={{ backgroundColor: c }} 
                      className={`w-10 h-10 rounded-full border-4 transition-all duration-300 hover:scale-110 active:scale-90 ${design.color === c ? 'border-white ring-2 ring-stone-900 shadow-xl' : 'border-transparent shadow-inner'}`}
                    ></button>
                  ))}
                </div>
             </div>
           )}
           
           {isGenerating && (
             <div className="absolute inset-0 bg-stone-100/90 backdrop-blur-md flex flex-col items-center justify-center z-20 animate-in fade-in duration-300">
               <div className="relative">
                 <Loader2 className="w-16 h-16 text-amber-600 animate-spin mb-6" />
                 <Sparkles className="w-6 h-6 text-amber-400 absolute top-0 right-0 animate-pulse" />
               </div>
               <p className="font-playfair font-bold text-xl text-stone-900">AI is crafting your vision...</p>
               <p className="text-stone-500 text-sm mt-2">Personalizing fabric textures and lighting</p>
             </div>
           )}
        </section>

        {/* Right: Detailed Controls */}
        <div className="space-y-10 overflow-y-auto pr-2 no-scrollbar">
          {activeTab === 'studio' ? (
            <section className="space-y-8 animate-in fade-in slide-in-from-right-8 duration-500">
              <div className="bg-amber-50 rounded-3xl p-6 border border-amber-100 flex items-center gap-4">
                <Sparkles className="w-8 h-8 text-amber-600" />
                <div>
                  <h3 className="text-amber-900 font-bold">AI Moodboard Studio</h3>
                  <p className="text-amber-800/70 text-sm">Visualize complete outfits using natural language.</p>
                </div>
              </div>
              
              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest block mb-2 px-1">Concept Prompt</label>
                  <textarea 
                    value={imagePrompt}
                    onChange={(e) => setImagePrompt(e.target.value)}
                    placeholder="e.g. A futuristic men's silk blazer with neon embroidery, professional catalog style, soft lighting"
                    className="w-full bg-stone-100 border border-transparent rounded-3xl px-6 py-5 text-sm focus:ring-2 focus:ring-amber-500 focus:bg-white outline-none h-40 transition-all shadow-inner"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest block mb-2 px-1">Aspect Ratio</label>
                    <select value={aspectRatio} onChange={(e) => setAspectRatio(e.target.value)} className="w-full bg-stone-100 rounded-2xl px-5 py-3.5 text-sm outline-none focus:ring-2 focus:ring-amber-500 transition-all">
                      {["1:1", "3:4", "4:3", "9:16", "16:9", "2:3", "3:2", "21:9"].map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-stone-400 uppercase tracking-widest block mb-2 px-1">Target Quality</label>
                    <select value={imageSize} onChange={(e) => setImageSize(e.target.value)} className="w-full bg-stone-100 rounded-2xl px-5 py-3.5 text-sm outline-none focus:ring-2 focus:ring-amber-500 transition-all">
                      {["1K", "2K", "4K"].map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                </div>
                <button 
                  onClick={handleGenerate}
                  disabled={isGenerating || !imagePrompt}
                  className="w-full bg-stone-900 text-white py-5 rounded-3xl font-bold flex items-center justify-center gap-3 shadow-2xl hover:bg-stone-800 transition-all disabled:opacity-50 active:scale-[0.98]"
                >
                  <ImageIcon className="w-5 h-5" /> Generate Inspiration
                </button>
              </div>
            </section>
          ) : activeTab === 'fabric' ? (
            <section className="space-y-12">
              {/* Fabric Selection */}
              <div className="space-y-6">
                <h3 className="text-xl font-bold flex items-center gap-2"><Paintbrush className="w-5 h-5 text-amber-600" /> Select Material</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {fabrics.map((f, i) => (
                    <button 
                      key={i} 
                      onClick={() => setDesign({...design, fabric: f.name})} 
                      className={`p-5 rounded-[32px] border-2 text-left transition-all hover:scale-[1.02] active:scale-95 ${design.fabric === f.name ? 'border-stone-900 bg-white shadow-xl' : 'border-stone-100 hover:border-stone-300'}`}
                    >
                      <img src={f.img} className="w-full h-36 object-cover rounded-2xl mb-4 shadow-sm" alt="" />
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-stone-900">{f.name}</span>
                        <span className="text-xs font-bold text-amber-600">{f.price}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Silhouette Controls with Thumbnails */}
              <div className="space-y-8 bg-white p-8 rounded-[40px] border border-stone-100 shadow-sm">
                <div>
                  <h4 className="text-sm font-bold text-stone-400 uppercase tracking-widest mb-4">Neckline Style</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {necklines.map(n => (
                      <button 
                        key={n.name} 
                        onClick={() => setDesign({...design, neckline: n.name})} 
                        className={`flex flex-col items-center gap-2 p-2 rounded-2xl transition-all border-2 ${design.neckline === n.name ? 'border-amber-500 bg-amber-50' : 'border-transparent hover:bg-stone-50'}`}
                      >
                        <img src={n.img} className="w-12 h-12 rounded-full object-cover shadow-sm" alt={n.name} />
                        <span className="text-[10px] font-bold uppercase tracking-tight">{n.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-bold text-stone-400 uppercase tracking-widest mb-4">Sleeve Length</h4>
                  <div className="grid grid-cols-3 gap-3">
                    {sleeves.map(s => (
                      <button 
                        key={s.name} 
                        onClick={() => setDesign({...design, sleeve: s.name})} 
                        className={`flex flex-col items-center gap-2 p-2 rounded-2xl transition-all border-2 ${design.sleeve === s.name ? 'border-amber-500 bg-amber-50' : 'border-transparent hover:bg-stone-50'}`}
                      >
                        <img src={s.img} className="w-12 h-12 rounded-full object-cover shadow-sm" alt={s.name} />
                        <span className="text-[10px] font-bold uppercase tracking-tight">{s.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <button 
                onClick={() => setActiveTab('measurements')} 
                className="w-full bg-stone-900 text-white py-5 rounded-[32px] font-bold flex items-center justify-center gap-3 shadow-2xl hover:bg-stone-800 transition-all group"
              >
                Configure Measurements 
                <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>
            </section>
          ) : (
            <div className="flex flex-col items-center justify-center py-24 text-center space-y-4 bg-stone-50 rounded-[40px] border border-dashed border-stone-300">
              <Ruler className="w-12 h-12 text-stone-300" />
              <div className="max-w-xs">
                <h4 className="font-bold text-stone-900">Standard Tailoring Workflow</h4>
                <p className="text-stone-400 text-sm mt-1">Please complete the fabric and silhouette selection to proceed to measurements.</p>
              </div>
              <button 
                onClick={() => setActiveTab('fabric')}
                className="mt-4 text-amber-600 font-bold text-sm underline"
              >
                Back to Silhouette
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CustomDesign;
