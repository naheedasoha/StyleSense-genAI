
import React, { useState, useEffect } from 'react';
import { AppRoute, Outfit } from '../types';
import { ArrowRight, Sparkles, TrendingUp, Scissors, Baby, User, Coffee, Bookmark, Trash2 } from 'lucide-react';

interface Props {
  navigate: (route: AppRoute) => void;
}

const Home: React.FC<Props> = ({ navigate }) => {
  const [savedOutfits, setSavedOutfits] = useState<(Outfit & { date: string })[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('styleSense_savedOutfits');
    if (saved) {
      setSavedOutfits(JSON.parse(saved));
    }
  }, []);

  const removeSavedOutfit = (title: string) => {
    const updated = savedOutfits.filter(o => o.title !== title);
    setSavedOutfits(updated);
    localStorage.setItem('styleSense_savedOutfits', JSON.stringify(updated));
  };

  return (
    <div className="flex flex-col overflow-x-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[70vh] md:h-[85vh] flex items-center px-4 sm:px-6 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=2070&auto=format&fit=crop" 
            className="w-full h-full object-cover"
            alt="Hero Background"
            loading="eager"
          />
          <div className="absolute inset-0 bg-stone-900/40"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto w-full py-20">
          <div className="max-w-2xl">
            <h1 className="text-4xl sm:text-6xl md:text-7xl font-playfair font-bold text-white mb-6 leading-tight">
              Elegance Powered <br className="hidden sm:block" />by <span className="text-amber-400">Intelligence.</span>
            </h1>
            <p className="text-lg sm:text-xl text-stone-100 mb-8 sm:mb-10 max-w-lg leading-relaxed font-light">
              Experience the future of fashion for every generation. Personalized styling, virtual try-ons, and traditional craftsmanship.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={() => navigate(AppRoute.RECOMMEND)}
                className="bg-white text-stone-900 px-8 py-4 rounded-full font-semibold flex items-center justify-center gap-2 hover:bg-amber-400 transition-all shadow-xl"
              >
                Get AI Styling <Sparkles className="w-5 h-5" />
              </button>
              <button 
                onClick={() => navigate(AppRoute.TRY_ON)}
                className="bg-stone-900/40 backdrop-blur-md border border-white/20 text-white px-8 py-4 rounded-full font-semibold hover:bg-white/10 transition-all"
              >
                Visual Try-On
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Saved Outfits Section */}
      {savedOutfits.length > 0 && (
        <section className="py-16 sm:py-24 px-4 sm:px-6 max-w-7xl mx-auto w-full border-b border-stone-100">
          <div className="mb-8">
            <div className="flex items-center gap-2 text-amber-600 text-xs font-bold tracking-widest uppercase mb-2">
              <Bookmark className="w-4 h-4" /> Style Vault
            </div>
            <h2 className="text-3xl font-playfair font-bold text-stone-900">Your Archive</h2>
          </div>
          <div className="flex gap-4 sm:gap-6 overflow-x-auto pb-6 snap-x no-scrollbar">
            {savedOutfits.map((outfit, i) => (
              <div key={i} className="min-w-[260px] sm:min-w-[300px] snap-start group">
                <div className="aspect-[4/5] bg-stone-100 rounded-2xl sm:rounded-3xl overflow-hidden mb-4 relative shadow-sm border border-stone-100">
                  <img src={outfit.primary.imageUrl} alt={outfit.title} className="w-full h-full object-cover transition-transform group-hover:scale-110" loading="lazy" />
                  <button onClick={() => removeSavedOutfit(outfit.title)} className="absolute top-4 right-4 bg-white/90 p-2 rounded-full text-red-500 shadow-md">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <h4 className="font-playfair font-bold text-lg text-stone-900 line-clamp-1">{outfit.title}</h4>
                <button onClick={() => navigate(AppRoute.RECOMMEND)} className="text-sm font-bold text-amber-600 flex items-center gap-1 mt-2">
                  View Look <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Main Categories */}
      <section className="py-16 sm:py-24 px-4 sm:px-6 max-w-7xl mx-auto w-full">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end mb-10 sm:mb-12 gap-4">
          <div>
            <h2 className="text-3xl font-playfair font-bold text-stone-900 mb-2">Collections</h2>
            <p className="text-stone-500 text-sm">Tradition meets contemporary trends.</p>
          </div>
          <button className="text-sm font-semibold text-amber-600 flex items-center gap-1">
            Browse All <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          <CategoryCard title="Traditional Men" img="https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?q=80&w=1887&auto=format&fit=crop" label="Festive" />
          <CategoryCard title="Traditional Women" img="https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1887&auto=format&fit=crop" label="Couture" />
          <CategoryCard title="Casual Men" img="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=1887&auto=format&fit=crop" label="Linen" />
          <CategoryCard title="Casual Women" img="https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=1887&auto=format&fit=crop" label="Minimalist" />
        </div>
      </section>

      {/* Generations */}
      <section className="bg-stone-900 py-20 sm:py-24 px-4 sm:px-6 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-3xl sm:text-4xl font-playfair font-bold mb-4">Style for Every Age</h2>
            <p className="text-stone-400 max-w-xl mx-auto text-sm sm:text-base">Personalized wardrobe evolution for the whole family.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            <GenerationCard icon={<Baby />} title="Kids" desc="Playful & soft." img="https://images.unsplash.com/photo-1471286174890-9c112ffca5b4?q=80&w=2070&auto=format&fit=crop" />
            <GenerationCard icon={<User />} title="Teens" desc="Trendsetting vibes." img="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1887&auto=format&fit=crop" />
            <GenerationCard icon={<Coffee />} title="Seniors" desc="Timeless elegance." img="https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=1888&auto=format&fit=crop" />
          </div>
        </div>
      </section>
    </div>
  );
};

const CategoryCard = ({ title, img, label }: { title: string, img: string, label: string }) => (
  <div className="group cursor-pointer relative rounded-2xl overflow-hidden h-[350px] sm:h-[400px] shadow-sm hover:shadow-xl transition-all">
    <img src={img} alt={title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
    <div className="absolute inset-0 bg-gradient-to-t from-stone-900/80 to-transparent"></div>
    <div className="absolute bottom-6 left-6 text-white">
      <p className="text-[10px] uppercase tracking-widest font-bold text-amber-400 mb-1">{label}</p>
      <h4 className="text-lg sm:text-xl font-playfair font-bold">{title}</h4>
    </div>
  </div>
);

const GenerationCard = ({ icon, title, desc, img }: { icon: any, title: string, desc: string, img: string }) => (
  <div className="relative h-64 sm:h-80 rounded-[24px] sm:rounded-[32px] overflow-hidden group cursor-pointer">
    <img src={img} className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" alt={title} loading="lazy" />
    <div className="absolute inset-0 bg-gradient-to-t from-stone-950/90 to-transparent"></div>
    <div className="absolute bottom-6 left-6 right-6">
      <h4 className="text-lg font-bold mb-1">{title}</h4>
      <p className="text-xs text-stone-300">{desc}</p>
    </div>
  </div>
);

export default Home;
