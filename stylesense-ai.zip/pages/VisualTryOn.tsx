
import React, { useState, useRef } from 'react';
import { AppRoute, Outfit } from '../types';
import { generateVirtualTryOn, generateVeoVideo, analyzeStyleImage } from '../services/geminiService';
import { Camera, Upload, Sparkles, RefreshCw, X, CheckCircle2, ShoppingBag, Loader2, Play, Info, Key } from 'lucide-react';

interface Props {
  navigate: (route: AppRoute) => void;
  selectedOutfit?: Outfit | null;
  userGender?: string;
}

const VisualTryOn: React.FC<Props> = ({ navigate, selectedOutfit, userGender }) => {
  const [mode, setMode] = useState<'selection' | 'camera' | 'upload' | 'analyzing' | 'result'>('selection');
  const [statusText, setStatusText] = useState('');
  const [userPhoto, setUserPhoto] = useState<string | null>(null);
  const [resultPhoto, setResultPhoto] = useState<string | null>(null);
  const [resultVideo, setResultVideo] = useState<string | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [customPrompt, setCustomPrompt] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const outfitDescription = selectedOutfit 
    ? `${selectedOutfit.primary.name} - ${selectedOutfit.primary.description}. ${selectedOutfit.bottom ? `With ${selectedOutfit.bottom.name}.` : ''}`
    : customPrompt;

  const startCamera = async () => {
    setMode('camera');
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (err) {
      setError("Could not access camera.");
      setMode('selection');
    }
  };

  const capturePhoto = () => {
    const canvas = document.createElement('canvas');
    if (videoRef.current) {
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(videoRef.current, 0, 0);
      const dataUrl = canvas.toDataURL('image/png');
      setUserPhoto(dataUrl);
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      handleProcess(dataUrl);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result as string;
        setUserPhoto(dataUrl);
        handleProcess(dataUrl);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProcess = async (imageBase64: string) => {
    setMode('analyzing');
    setError(null);
    try {
      // Step 1: Analyze Style (Sequential to avoid 429)
      setStatusText('Analyzing your current look...');
      const styleAnalysis = await analyzeStyleImage(imageBase64);
      setAnalysis(styleAnalysis);

      // Step 2: Virtual Try-On
      setStatusText('Generating your virtual try-on...');
      const generatedImage = await generateVirtualTryOn(imageBase64, outfitDescription || "Stylish outfit", userGender || "person");
      setResultPhoto(generatedImage);
      
      setMode('result');
    } catch (err: any) {
      console.error(err);
      if (err.message?.includes('429')) {
        setError("Our AI servers are momentarily busy. Please try again in 10-15 seconds.");
      } else {
        setError("Style processing failed. Please try a different photo.");
      }
      setMode('selection');
    }
  };

  const handleAnimate = async () => {
    const hasKey = await (window as any).aistudio.hasSelectedApiKey();
    if (!hasKey) {
      await (window as any).aistudio.openSelectKey();
    }

    setIsAnimating(true);
    try {
      const prompt = `A cinematic fashion video of this person walking gracefully, showcasing the outfit with realistic motion and fabric physics.`;
      const videoUrl = await generateVeoVideo(prompt, resultPhoto || userPhoto || undefined, true);
      setResultVideo(videoUrl);
    } catch (e) {
      alert("Animation requires an active billing plan. Visit: ai.google.dev/gemini-api/docs/billing");
    } finally {
      setIsAnimating(false);
    }
  };

  return (
    <div className="min-h-screen bg-stone-950 text-white flex flex-col">
      <div className="p-6 flex justify-between items-center border-b border-stone-800">
        <div className="flex items-center gap-3">
          <Sparkles className="w-6 h-6 text-amber-500" />
          <h2 className="text-xl font-playfair font-bold">AI Visual Studio</h2>
        </div>
        <button onClick={() => navigate(AppRoute.HOME)} className="text-stone-400 hover:text-white transition-colors">
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-6">
        {mode === 'selection' && (
          <div className="max-w-2xl w-full text-center space-y-12 animate-in fade-in zoom-in duration-500">
            <div>
              <div className="w-20 h-20 bg-stone-900 rounded-[32px] flex items-center justify-center mx-auto mb-8 border border-stone-800 shadow-2xl">
                <Sparkles className="w-10 h-10 text-amber-500" />
              </div>
              <h1 className="text-4xl md:text-5xl font-playfair font-bold mb-4">Digital Wardrobe <br/>Simulation</h1>
              <p className="text-stone-400 max-w-md mx-auto mb-10 leading-relaxed">Analyze your current aesthetic and visualize yourself in new designer silhouettes using professional AI.</p>
              
              {error && (
                <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-2xl text-sm mb-8 animate-pulse">
                  {error}
                </div>
              )}

              {!selectedOutfit && (
                <div className="bg-stone-900/50 backdrop-blur-xl p-6 rounded-[32px] border border-white/5 mb-8 shadow-inner">
                  <label className="text-[10px] font-bold text-stone-500 uppercase tracking-widest block mb-3 ml-1 text-left">Custom Style Prompt</label>
                  <input 
                    type="text" 
                    value={customPrompt} 
                    onChange={(e) => setCustomPrompt(e.target.value)} 
                    placeholder="e.g. A sophisticated Italian silk blazer in emerald green..." 
                    className="w-full bg-stone-950 border border-stone-800 rounded-2xl px-5 py-4 text-sm focus:ring-2 focus:ring-amber-500 outline-none transition-all" 
                  />
                </div>
              )}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <button onClick={startCamera} className="bg-white text-stone-900 p-8 rounded-[40px] flex flex-col items-center gap-4 hover:bg-amber-400 transition-all shadow-2xl active:scale-95 group">
                <Camera className="w-8 h-8 group-hover:scale-110 transition-transform" />
                <span className="font-bold tracking-tight">Open Studio Camera</span>
              </button>
              <label className="bg-stone-900 border border-stone-800 p-8 rounded-[40px] flex flex-col items-center gap-4 hover:bg-stone-800 cursor-pointer transition-all shadow-2xl active:scale-95 group">
                <Upload className="w-8 h-8 text-stone-400 group-hover:text-white group-hover:scale-110 transition-all" />
                <span className="font-bold tracking-tight">Upload High-Res Photo</span>
                <input type="file" className="hidden" onChange={handleFileUpload} accept="image/*" />
              </label>
            </div>
          </div>
        )}

        {mode === 'camera' && (
          <div className="relative w-full max-w-2xl aspect-[3/4] rounded-[48px] overflow-hidden bg-stone-900 shadow-[0_0_100px_rgba(0,0,0,0.5)] border-4 border-stone-800">
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover scale-x-[-1]" />
            <div className="absolute inset-x-0 bottom-12 flex justify-center gap-8 items-center px-10">
              <button onClick={() => setMode('selection')} className="w-16 h-16 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center border border-white/10 hover:bg-white/20 transition-all">
                <X className="w-8 h-8" />
              </button>
              <button onClick={capturePhoto} className="w-20 h-20 bg-white rounded-full p-1 ring-4 ring-white/30 flex items-center justify-center hover:scale-105 active:scale-90 transition-all">
                <div className="w-full h-full bg-white rounded-full border-4 border-stone-950"></div>
              </button>
              <div className="w-16 h-16"></div> {/* Spacer for symmetry */}
            </div>
          </div>
        )}

        {mode === 'analyzing' && (
          <div className="text-center animate-in fade-in duration-700">
            <div className="relative w-40 h-40 mx-auto mb-10">
              <div className="absolute inset-0 rounded-full border-4 border-stone-800"></div>
              <div className="absolute inset-0 rounded-full border-4 border-amber-500 border-t-transparent animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Sparkles className="w-10 h-10 text-amber-500 animate-pulse" />
              </div>
            </div>
            <h3 className="text-3xl font-playfair font-bold mb-3">{statusText}</h3>
            <p className="text-stone-500 text-sm max-w-xs mx-auto">This multi-step AI orchestration ensures the highest quality fashion results.</p>
          </div>
        )}

        {mode === 'result' && (
          <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 gap-16 items-center animate-in fade-in slide-in-from-bottom-12 duration-1000">
            <div className="relative aspect-[3/4] rounded-[56px] overflow-hidden shadow-[0_40px_100px_rgba(0,0,0,0.8)] bg-stone-900 border border-white/5 group">
               {resultVideo ? (
                 <video src={resultVideo} controls autoPlay className="w-full h-full object-cover" />
               ) : (
                 <img src={resultPhoto || ''} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" />
               )}
               {isAnimating && (
                 <div className="absolute inset-0 bg-black/80 backdrop-blur-2xl flex flex-col items-center justify-center text-center p-12 z-20">
                    <Loader2 className="w-16 h-16 text-amber-500 animate-spin mb-8" />
                    <h4 className="font-playfair font-bold text-2xl mb-4">Veo 3.1 Cinematic Animation</h4>
                    <p className="text-sm text-stone-400 leading-relaxed">Generating photorealistic motion frames for a high-end runway preview.</p>
                 </div>
               )}
               <div className="absolute top-8 left-8">
                 <span className="bg-black/60 backdrop-blur-xl border border-white/10 px-5 py-2.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em]">AI Visual Export</span>
               </div>
            </div>

            <div className="space-y-10">
              <div className="bg-stone-900/40 backdrop-blur-xl border border-white/5 p-10 rounded-[48px] shadow-2xl">
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-12 h-12 bg-amber-500 rounded-2xl flex items-center justify-center shadow-[0_0_30px_rgba(245,158,11,0.3)]">
                    <CheckCircle2 className="w-7 h-7 text-stone-900" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg">Curated Style Analysis</h4>
                    <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest">Gemini Engine V3</p>
                  </div>
                </div>
                <div className="relative">
                  <p className="text-stone-300 leading-relaxed italic border-l-4 border-amber-500/50 pl-6 py-2">{analysis}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                 <button onClick={handleAnimate} disabled={isAnimating} className="bg-white text-stone-900 py-5 rounded-3xl font-bold flex items-center justify-center gap-3 hover:bg-amber-400 transition-all shadow-2xl active:scale-95 disabled:opacity-30 group">
                   <Play className="w-5 h-5 group-hover:fill-current" /> {resultVideo ? 'Regenerate Motion' : 'Animate Runway (Veo)'}
                 </button>
                 <button onClick={() => setMode('selection')} className="bg-stone-800/80 backdrop-blur-md border border-white/10 py-5 rounded-3xl font-bold hover:bg-stone-700 transition-all active:scale-95">Reset Studio</button>
              </div>
              <div className="flex items-center gap-2 text-[10px] text-stone-500 uppercase font-bold justify-center tracking-widest">
                 <Info className="w-3 h-3 text-amber-600" /> Professional video requires active billing.
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default VisualTryOn;
