
export interface RecommendationRequest {
  gender: string;
  ageGroup: string;
  occasion: string;
  fabric: string;
  style: string;
  budget: string;
}

export interface ClothingItem {
  id: string;
  name: string;
  type: string;
  description: string;
  price: number;
  imageUrl: string;
  category: 'primary' | 'accessory' | 'footwear' | 'bag';
}

export interface Outfit {
  title: string;
  primary: ClothingItem;
  bottom?: ClothingItem;
  accessories: ClothingItem[];
  footwear: ClothingItem;
  bag?: ClothingItem;
  celebrityInspo: {
    name: string;
    description: string;
    occasion: string;
    imageUrl: string;
  };
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isGrounded?: boolean;
  sources?: Array<{ web?: { uri: string; title: string } }>;
}

export enum AppRoute {
  LOGIN = 'login',
  HOME = 'home',
  RECOMMEND = 'recommend',
  TRY_ON = 'try-on',
  CUSTOM = 'custom',
  CHECKOUT = 'checkout'
}
