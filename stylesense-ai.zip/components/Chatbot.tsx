
import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, Send, X, User, Sparkles, ArrowRight, Baby, GraduationCap, Coffee, Globe } from 'lucide-react';
import { getStylistChatResponse } from '../services/geminiService';
import { ChatMessage, AppRoute } from '../types';

interface Props {
  navigate?: (route: AppRoute) => void;
  userContext?: { ageGroup?: string; gender?: string };
}

const Chatbot: React.FC<Props> = ({ navigate, userContext }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'Hello! I am your StyleSense AI stylist. I now have real-time Google Search grounding. Ask me about current trends!' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async (customPrompt?: string) => {
    const textToSend = customPrompt || input;
    if (!textToSend.trim() || isLoading) return;

    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: textToSend }]);
    setIsLoading(true);

    try {
      const response = await getStylistChatResponse(messages, textToSend, userContext);
      setMessages(prev => [...prev, { 
        role: 'model', 
        text: response.text,
        isGrounded: response.isGrounded,
        sources: response.sources
      }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: 'Apologies, I hit a snag. Let me try again later.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const renderMessageContent = (msg: ChatMessage) => {
    const text = msg.text;
    const showRecommend = text.toLowerCase().includes('ai stylist') || text.toLowerCase().includes('recommendation');
    const showCustom = text.toLowerCase().includes('atelier') || text.toLowerCase().includes('custom design');

    return (
      <div className="space-y-3">
        <p>{text}</p>
        
        {msg.isGrounded && (
          <div className="pt-2 border-t border-stone-100 mt-2">
            <div className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-600 mb-1">
              <Globe className="w-3 h-3" /> VERIFIED BY GOOGLE SEARCH
            </div>
            {msg.sources && msg.sources.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {msg.sources.map((s: any, idx: number) => (
                  s.web && (
                    <a key={idx} href={s.web.uri} target="_blank" rel="noopener noreferrer" className="text-[10px] text-stone-400 underline hover:text-stone-600 truncate max-w-[150px]">
                      {s.web.title || 'Source'}
                    </a>
                  )
                ))}
              </div>
            )}
          </div>
        )}

        {(showRecommend || showCustom) && navigate && (
          <div className="flex flex-wrap gap-2 pt-2">
            {showRecommend && (
              <button onClick={() => navigate(AppRoute.RECOMMEND)} className="text-[10px] bg-amber-100 text-amber-800 px-3 py-1.5 rounded-full font-bold flex items-center gap-1 hover:bg-amber-200">
                Go to AI Stylist <ArrowRight className="w-2.5 h-2.5" />
              </button>
            )}
            {showCustom && (
              <button onClick={() => navigate(AppRoute.CUSTOM)} className="text-[10px] bg-stone-100 text-stone-800 px-3 py-1.5 rounded-full font-bold flex items-center gap-1 hover:bg-stone-200">
                Go to Atelier <ArrowRight className="w-2.5 h-2.5" />
              </button>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-stone-900 text-white p-4 rounded-full shadow-2xl hover:bg-stone-800 transition-all flex items-center gap-2 group"
        >
          <Sparkles className="w-5 h-5 text-amber-400" />
          <span className="font-medium">AI Stylist</span>
        </button>
      )}

      {isOpen && (
        <div className="bg-white w-80 md:w-96 h-[550px] rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-stone-100 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="bg-stone-900 p-5 flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-amber-400 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-stone-900" />
              </div>
              <h3 className="text-white text-sm font-bold">StyleSense AI</h3>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-stone-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-stone-50 no-scrollbar">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-4 rounded-2xl text-sm leading-relaxed ${
                  msg.role === 'user' 
                    ? 'bg-stone-900 text-white rounded-tr-none' 
                    : 'bg-white border border-stone-200 text-stone-800 rounded-tl-none'
                }`}>
                  {msg.role === 'model' ? renderMessageContent(msg) : msg.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white border border-stone-200 p-4 rounded-2xl text-stone-400 text-xs italic">
                  Stylist is thinking...
                </div>
              </div>
            )}
          </div>

          <div className="p-4 bg-white border-t border-stone-100">
            <div className="flex gap-2 relative">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask about 2024 trends..."
                className="flex-1 bg-stone-100 rounded-2xl px-5 py-3.5 text-sm focus:ring-2 focus:ring-amber-400 outline-none"
              />
              <button
                onClick={() => handleSend()}
                disabled={isLoading || !input.trim()}
                className="bg-stone-900 text-white p-3.5 rounded-2xl disabled:opacity-30"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Chatbot;
