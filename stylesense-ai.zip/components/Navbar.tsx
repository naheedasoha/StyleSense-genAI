
import React from 'react';
import { AppRoute } from '../types';
import { ShoppingBag, User, Sparkles, Scissors, Menu } from 'lucide-react';

interface Props {
  navigate: (route: AppRoute) => void;
  currentRoute: AppRoute;
}

const Navbar: React.FC<Props> = ({ navigate, currentRoute }) => {
  return (
    <nav className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-stone-100 px-4 sm:px-6 py-3 sm:py-4" aria-label="Main Navigation">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <button 
          onClick={() => navigate(AppRoute.HOME)} 
          className="text-xl sm:text-2xl font-playfair font-bold tracking-tight text-stone-900 focus:outline-none"
        >
          StyleSense<span className="text-amber-600">AI</span>
        </button>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-6">
          <NavLink 
            onClick={() => navigate(AppRoute.RECOMMEND)} 
            active={currentRoute === AppRoute.RECOMMEND} 
            icon={<Sparkles className="w-4 h-4" />} 
            label="Stylist" 
          />
          <NavLink 
            onClick={() => navigate(AppRoute.CUSTOM)} 
            active={currentRoute === AppRoute.CUSTOM} 
            icon={<Scissors className="w-4 h-4" />} 
            label="Atelier" 
          />
          <NavLink 
            onClick={() => navigate(AppRoute.TRY_ON)} 
            active={currentRoute === AppRoute.TRY_ON} 
            label="Try-On" 
          />
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3 sm:gap-5">
          <button 
            onClick={() => navigate(AppRoute.CHECKOUT)} 
            className="text-stone-600 relative p-2"
            aria-label="Bag"
          >
            <ShoppingBag className="w-5 h-5" />
            <span className="absolute top-1 right-1 bg-amber-600 text-white text-[9px] w-3.5 h-3.5 rounded-full flex items-center justify-center font-bold">2</span>
          </button>
          <button className="text-stone-600 p-2 hidden sm:block">
            <User className="w-5 h-5" />
          </button>
          {/* Mobile Menu Icon (Placeholder for functionality) */}
          <button className="md:hidden text-stone-600 p-2">
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </div>
    </nav>
  );
};

const NavLink = ({ onClick, active, icon, label }: { onClick: () => void, active: boolean, icon?: any, label: string }) => (
  <button 
    onClick={onClick}
    className={`text-sm font-semibold transition-colors flex items-center gap-1.5 px-2 py-1 ${active ? 'text-amber-600' : 'text-stone-500 hover:text-stone-900'}`}
  >
    {icon}
    {label}
  </button>
);

export default Navbar;
