
import React, { useState } from 'react';
import { AppRoute, Outfit } from './types';
import Login from './pages/Login';
import Home from './pages/Home';
import RecommendationFlow from './pages/RecommendationFlow';
import VisualTryOn from './pages/VisualTryOn';
import CustomDesign from './pages/CustomDesign';
import Checkout from './pages/Checkout';
import Navbar from './components/Navbar';
import Chatbot from './components/Chatbot';

const App: React.FC = () => {
  const [currentRoute, setCurrentRoute] = useState<AppRoute>(AppRoute.LOGIN);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  // Shared context for the Chatbot to know who it is talking to
  const [userContext, setUserContext] = useState<{ageGroup?: string, gender?: string}>({});
  // Shared context for Visual Try On to know what to render
  const [selectedOutfit, setSelectedOutfit] = useState<Outfit | null>(null);

  const navigate = (route: AppRoute) => {
    setCurrentRoute(route);
    window.scrollTo(0, 0);
  };

  const renderRoute = () => {
    switch (currentRoute) {
      case AppRoute.LOGIN:
        return <Login onLogin={() => { setIsAuthenticated(true); navigate(AppRoute.HOME); }} />;
      case AppRoute.HOME:
        return <Home navigate={navigate} />;
      case AppRoute.RECOMMEND:
        return (
          <RecommendationFlow 
            navigate={navigate} 
            onUpdateContext={setUserContext} 
            onSelectOutfit={setSelectedOutfit}
          />
        );
      case AppRoute.TRY_ON:
        return (
          <VisualTryOn 
            navigate={navigate} 
            selectedOutfit={selectedOutfit} 
            userGender={userContext.gender} 
          />
        );
      case AppRoute.CUSTOM:
        return <CustomDesign navigate={navigate} />;
      case AppRoute.CHECKOUT:
        return <Checkout navigate={navigate} />;
      default:
        return <Home navigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-stone-50">
      {isAuthenticated && <Navbar navigate={navigate} currentRoute={currentRoute} />}
      <main className="flex-grow">
        {renderRoute()}
      </main>
      {isAuthenticated && <Chatbot navigate={navigate} userContext={userContext} />}
      {isAuthenticated && (
        <footer className="bg-stone-900 text-stone-400 py-12 px-6">
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <h2 className="text-white font-playfair text-2xl font-bold mb-4">StyleSense AI</h2>
              <p className="max-w-xs">Redefining personal styling through the lens of artificial intelligence. Your journey to perfect fashion starts here.</p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Explore</h4>
              <ul className="space-y-2 text-sm">
                <li><button onClick={() => navigate(AppRoute.HOME)}>Home</button></li>
                <li><button onClick={() => navigate(AppRoute.RECOMMEND)}>AI Recommendation</button></li>
                <li><button onClick={() => navigate(AppRoute.TRY_ON)}>Visual Try-On</button></li>
                <li><button onClick={() => navigate(AppRoute.CUSTOM)}>Custom Outfits</button></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Connect</h4>
              <ul className="space-y-2 text-sm">
                <li>Instagram</li>
                <li>Twitter</li>
                <li>Fashion Blog</li>
                <li>Support</li>
              </ul>
            </div>
          </div>
          <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-stone-800 text-xs text-center">
            &copy; 2024 StyleSense AI. All rights reserved.
          </div>
        </footer>
      )}
    </div>
  );
};

export default App;
